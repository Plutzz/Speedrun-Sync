# BossSync

An extension mod for ItemSync that syncs boss kills, ensuring that players don't have to defeat bosses that other players in their ItemSync have already completed. Useful for co-op speedrunning!

# Dependencies
- ItemSync
- MenuChanger
- Randomizer 4
- RecentItemsDisplay
